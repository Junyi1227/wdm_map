月明湖對岸石景修正版：中央高兩側低，下寬上窄、陡峭且有厚度。
三個分件：upper-rocks、water、summit-pavilion。
不包含白色樓梯、人工坡道、後坡道路或湖岸下層石景。前後道路沿用原地圖。
landmark.blend 內 LANDMARK editable model 集合可編輯個別岩石。
map-*.glb 已標準化分件原點，場景偏移記於 map-parts.json。
尺寸與背面構造是估計，水流為靜態示意。

主體已移除整片斜坡／平面基體，改由獨立石塊交錯堆疊；底層較寬、上層收窄，亭下有支撐石。各石塊可在Blender中分別調整。
